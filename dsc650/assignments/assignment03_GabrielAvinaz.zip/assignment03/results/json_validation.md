JSONL lines with failed validation
----------------------------------
