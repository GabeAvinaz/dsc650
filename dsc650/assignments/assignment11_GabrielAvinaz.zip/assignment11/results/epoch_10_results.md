--- Generating with seed: " angrily, 'you ought to pay for all the damage yourselves an"
------ temperature:0.2
 angrily, 'you ought to pay for all the damage yourselves and stars of the mountains of the enemy was a stream that the wing and gandalf that they should not see them and stood and stars that the ring that the water of the ring of the ring in the shire. they should be still stood and stream that he saw them and stone stars of the morning of the morning of the ring of the morning of the enemy was still and stars and stars of the shire. they should be stood 
------ temperature:0.5
till and stars and stars of the shire. they should be stood off and destroy on the panes like shadows like a coming and strong that he could went stars of the hills that he saw the night than the stars of some they should be stars and the wood and stone come to the tray of the shire. in the road of the wise and the shire. the silver baggins after its head. they leave him was been forget of the ring, of the breath of the enemy creature the shire, strider sp
------ temperature:1.0
g, of the breath of the enemy creature the shire, strider spation to thicd. 
     when i lost nearer up the wone of the passing crold, come, and only i should recaulo unn'trow, he was said along this and plessing spather in gindle, hunger and sigue long tos his scame sam song! if he down the danger, lost passing as they stepting bown with him, but hen 'and ho padil before i ptoped him, and i do not formust. frodo gaved to count down. but i am merry with di
------ temperature:1.2
t formust. frodo gaved to count down. but i am merry with disastingloon of the master of gimle. i coment old pony,' said merrys. 'i and wander iccvew load.
     you,m refondel! how! rohanom! tom, but all i, his head of iunderedat brought hobbit-shood crolled his cloans,' sam are ginde good noke some roots,' said ara_dws _stand; for thougharmers i cannot good over with creckling fows cannot riden honsance. bro.'
     't port cks on the orc mrownonause talk,
