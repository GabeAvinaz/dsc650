--- Generating with seed: "ned like a swan,
           and light upon her banners laid."
------ temperature:0.2
ned like a swan,
           and light upon her banners laid.

     'and the wise of the world the sound of the shadows of the shire and the hobbits. the wise to the shire the more than the wise. i am burning the elves of the shire the stream and the shire in the shadows and the shire was strange shall and the grey forest of the land and the shire and the hobbits and the trees of the world of the shire the breath and the shire the company was the first were
------ temperature:0.5
hire the breath and the shire the company was the first were help in the shadows of the dark line stone word of the shadows. they shut in the tree to the first work and a name to help into the fell. the gate of long and slong halls of the shire are shall be a shoulder of the shire and set in the dark light in a small behind the closes placed the renerth,' he said. 'the sent and far some that he was store in the shadows before the shire he was to the shire.
------ temperature:1.0
s store in the shadows before the shire he was to the shire. the net a his way as wy. there was close too friend.

     gandalf, and i had thoy further. ofh got theve where the three more, tell we put if anxedy sam! though he sips was noted till was coping leugoning or mirkwood and lands. when i had betwer it ired. and each noib it understanted suddenly at letth now to the errohide in the maon the tooks bangory in the doors. soon he was noting leave that m
------ temperature:1.2
 tooks bangory in the doors. soon he was noting leave that mi't the whitematters going old grgy ench_cttents.


           no bree, itgr moriones and gan a lice of the yeare? amagt csome go , `why is i are step of of when it cide it's you not left impalmant.
     but in the water:


      he in't we can go tooks i had togeth hurt. 'let meet,' said the shapps, they prove for the dusk.

     'wide invincidet one of a pooling wituden ere there.  velwed elpear
