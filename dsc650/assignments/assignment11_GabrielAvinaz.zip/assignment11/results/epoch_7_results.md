--- Generating with seed: "ys and nights that they had passed there. as they stood for "
------ temperature:0.2
ys and nights that they had passed there. as they stood for the shadow of the shadow of the water was and stood and seement the world. the ring was seemed to the world. it was a seement and stood and stood and the world. the wood and a shadow of the shadow of the water of the shadow of the woods of the water of the shadow of the shadow of the woods and stood the sun was seemed the water was soon the shadow of the water of the shadow of the shadow of the wa
------ temperature:0.5
he shadow of the water of the shadow of the shadow of the way and well heard it was soon that lies for the way that i was the west of him was some of the water words. the elves were before the short in the stories of the short crickher of the water of the feet the moon of the fire and the stars of the world was make a clear down the short and heard. the march was stood the other speer in the long bush. he think the elves the sword of the darkness was so fa
------ temperature:1.0
bush. he think the elves the sword of the darkness was so fair, evile to se'te that whatevborth again it wihdins of the land a ganes of him.'
     'whoy' he lavonis coming, we tapped in its walling opening might-gently was sadone and for they?' said shelty. `you will us a snort who long horse.
     ' 'lears the farrord.
           like many. i your gate of the dark prestyping to the moand their ansoothage. don't eared the east. hobbits. but i mu
     bone 
------ temperature:1.2
soothage. don't eared the east. hobbits. but i mu
     bone was , hi's this eaytwill and tonibt. and of could betth glass. all, and his eapthen walious.
     the heds. i ned, nor feel in plal clos. lawe passage that nabtahderds than guned is an?
           one of morua, thright could with distenteroth nights, a dams anourom. yet someunn things on, tell eatwnoeis try site coming.'
     the destre. it is one werement of an obves of the momtance, the doubt wa
