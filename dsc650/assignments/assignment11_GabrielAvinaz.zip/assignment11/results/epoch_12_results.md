--- Generating with seed: " they came and planted themselves right by it, and leaned ov"
------ temperature:0.2
 they came and planted themselves right by it, and leaned over the way the shire that the wind was stream that the stars of the stream was stream that the starts of the mountains that he was not the hobbits and the starts of the trees and the winds and the world and the shadow of the starts of the stream was a long and stream the startly. the stream was strange stream the words of the stream was stream that the wind was and for a long the starts of the sta
------ temperature:0.5
tream that the wind was and for a long the starts of the starts, and now sam stuldil to have well the bridge strange deep with light and the way before them. but the hooth of the counslons things the ancient high of a moment there were must me. the stream was little and the shire of the sung the sound of the world it seemed to his eyes and great black and shadow. the riders the brow the trees, the hobbits were there will not fougnt the words with the willi
------ temperature:1.0
 hobbits were there will not fougnt the words with the willing unsgrin, mose hoom-portly.'
     never over it had the dangs dill trolls for then the laughs in the elves!  gounf now even coned, and the turn to tring out or bust was notpers through cast peaps was shurt on be in the lame or nowes dragged off,y his step a bridge, clear which went in . there the sound now needed the wonder.
     'youy cleea. frodo was notins thally mr. buthorubenland his thougs
------ temperature:1.2
cleea. frodo was notins thally mr. buthorubenland his thougson yearon now on the saurs, then forneiwely hand middle-quickling his stream into been curned behind. after open. there was still surprit down. it veep. but he was dell, if aragorn passed at the dirg had knew owtions me to be now,' answered pippin. 'twiling wowefut the clear guess. boats best meint ridance. fand, and them was faileromep glasss. ahead. but i leaves, biluuble sawnf-brandywoilm. but 
