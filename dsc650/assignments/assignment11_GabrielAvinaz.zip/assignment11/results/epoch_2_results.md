--- Generating with seed: "nd the next, still whistling and crying:

          hey! now"
------ temperature:0.2
nd the next, still whistling and crying:

          hey! now i was and the fire and the shire the way to stayed the wind the wind of the strange the shout of the wind of the great right and the weather the shouted the wind of the stream was and the land were shadow were shadow the shire the shadow of the shire the count and the stream were strange the way to the wind of the world the shadow and the strange the way the wind of the way the for the dark was a
------ temperature:0.5
e strange the way the wind of the way the for the dark was and heard the worse which he is both can it, and the come to a stay go hard strange in the wight of the shadow and frodo still to go our land them stepped the fairer the shadow had not the dwarves of the fire the way as if the way, and i say the shadow me were to the eastern and the shouted he was in his fatters was borde and the stride was and leaved the classed the stard had no be, but a some sho
------ temperature:1.0
s and leaved the classed the stard had no be, but a some shout of oster precially lights was `and recaped! and the great unting by ease with the black shadow hadn they are. we must see to was for looking on anyorail. they idee.
     mistyd his fingers wat,' said  some sig, the froeon the owe last, . even fould down and the woeld room.'
     'men no was layed in the meaning manyk. make ut how but the eight fear azas. whet i was or the road. we should need w
------ temperature:1.2
he eight fear azas. whet i was or the road. we should need with fills of eledgimbullor., opersod dwarf. he sunking frodomies, frow it danger ast? nebse! igst was brieg light. ledo on at the way. but yet. passed frodo lay. but of them. the feal for journem whitherland a red soon isess with i aw and set iglalloranws' of what and the couther. frodo fell drew care, it my.
     sat no go both had shorts!
? `led usch he gone latt, her free thing, and there is on
