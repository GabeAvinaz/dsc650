--- Generating with seed: "ur names, sir?'
     'mr. took and mr. brandybuck,' said fro"
------ temperature:0.2
ur names, sir?'
     'mr. took and mr. brandybuck,' said frodo. 'but i should say that the sound of the ring to the middle of the shire. the ring seemed to be a strange falls of the ring to the enemy of the hill. the stream was still and the stream was a strange they were all the ring to the road and the stream was and be a strange was still folk and the ring to the shire. the ring was a strange was still the water of the ring to the shadows of the ring to
------ temperature:0.5
as still the water of the ring to the shadows of the ring to fany trees. for it seemed to be in the water, and the head they felt and new of the woods of the ring began to be all the world that with his eyes. the doom was seemed to be a distant first. and i was still he standing to have seemed to be found it will soon as with his wall of belowed for a langer and he will see back the light they are an enough still boats hote was starses, and minasitend the 
------ temperature:1.0
 an enough still boats hote was starses, and minasitend the coutagked chinged wined. time green had once grey the tumbs of the boats. the for weak kings. neither the followess had got ragear, that refelt little keltered enough, drowned to been fair, like accedd!' said strided. `so the took, frodo! for then going other seldom of the river-bridgil, for even because he done, sidding until the workdoos of enemy last destelr any coming orn opening and some in a
------ temperature:1.2
s of enemy last destelr any coming orn opening and some in as held you sending soon is dwarves. liet it with a scan a nects things through the shire-removener-fool'. `what chapne of that i've stood mawny themly 'ssrue's wingingem! the winter
           vely plip's that loud weeking keith fair and contaice,' he are weds of red seeded folk you go botter.'
     but of him knew he phoses that talking wecent. the valley as through the lateit with his forest tim
