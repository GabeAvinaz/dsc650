--- Generating with seed: " came to his first serious check. before him stood a wide da"
------ temperature:0.2
 came to his first serious check. before him stood a wide days of the sound of the trees of the dark than the stream the shire of the stream the swift and the mountains of the sun with the stream the sun with the strange of the trees of the sun they were and forget that the water was strider that we can the black company and the shire that was strider and the elves of the shadow of the shoulders were short that he saw a shadow of the farmer of the shadow w
------ temperature:0.5
ere short that he saw a shadow of the farmer of the shadow was morning the samer long cleared that they had been and see of a strength with a sun in the shadow of the shadow they even it are the fordes ready and left his take starts, and a long see no with the fear that they shall be galadriel of the lands of the sunder of this thing for me best be going to see that his finath the stranger from the same with some ring that rone as he found the brandy least
------ temperature:1.0
e same with some ring that rone as he found the brandy least of still back us,' said galadre, not until the sed the further to a fire.
     'nop' reaking enry sam sat that set sign, this were also be their climbs way. got me with downhise. and shings. strider, and it anger and never silverraved it glanged all asking. but when the call he sat if his mine, i think i passed where through a speed of the reating misughazw: he passed, and this neale it clipped, 
------ temperature:1.2
he reating misughazw: he passed, and this neale it clipped, running about his swift again with hisived spards voouwarve, 'alas one ring his cucion omid, nor go rider from stardled, steps one bemorg-perrairs.
     they halted to sleeny.
     iurhovel that valier backen. in spit been is gold; and it will here?' he they abomide,
           he stone.
     only stayper join dwarfihd; but in iniced.

     and theregly much as you with became and a cancough by me
