--- Generating with seed: " he looked very much like a dwarf.
     'i am sure you have "
------ temperature:0.2
 he looked very much like a dwarf.
     'i am sure you have a great stone of the stream the shadows of the great stream in the stream the road the shire the stream the stream the stream the stream the shadows and see them the stream the stream the stream the parts of the stream the stream the shadows of the sound of the stream the stream the stream the stream the stream them and the stream the stream the ring and for the hobbits were a strange the stream t
------ temperature:0.5
eam the ring and for the hobbits were a strange the stream the the ring got to the great rivents from the water of the stone and the road, and it may come by the fatty lang the hill of the hand and sam that is them and the the stretchet to the road some northern strong with his fair and will plain the broad stream and the still of the rings and the watches the lands of the shore of the mating the star that he was seemed to be great and be still and strange
------ temperature:1.0
star that he was seemed to be great and be still and strange and lets
            boromir destroreh coullk ending,_ he had till talls, eving in his heard footwanded helms. in tall,' said gandalf longed. 'ind as if frodo, untry, '  ventry away; but the room and easite,' he remeded and slowly still grass ran aim out of in already go in the fire grossed. i must you you fonneskence,
           to staff the hobbit whisted yet gaoms outseers!'
     'a will rown 
------ temperature:1.2
f the hobbit whisted yet gaoms outseers!'
     'a will rown not loct wests, thening untouceer,.
     'pro_vicely came her gathed you, not difprisiun, and windles of thanks. at latester in their fair they id  for it.
     'it would prept theset thereg's dark; and walk, known i periots at the mountainssessofe to still there got to them: darking through the oam signce of cry. he arose;astuadwening howing basied,' but wrider from the tree bnasky me; it would t
