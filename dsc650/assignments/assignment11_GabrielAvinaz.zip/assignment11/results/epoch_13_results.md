--- Generating with seed: "r flocks of birds had been circling, black against the pale "
------ temperature:0.2
r flocks of birds had been circling, black against the pale had a seemed to have been stood and stood and stood the strange strange strong was strider strider and start to the shire was stood and stay the shadows of the shadows of the shadows of the stone of the strong was a strange stood of the strange strong was stood and strong his hands and the shadows of the shadows of the shadows of the shadows of the shadows of the strange strong was forget the stra
------ temperature:0.5
ows of the shadows of the strange strong was forget the strange his tom and his stoulder. they were startly could feel it had a hard has been stoulder of the isset with his hands to do make your same of the way harm lay that we have not bear in the westernough things things from the silver hobbits, and i will have been of the first with the south of the string than he was still have had much of the windows, and the road with the windows and slowly for the 
------ temperature:1.0
e windows, and the road with the windows and slowly for the striget fair. then with a few attravely much made criept. our things tarver hillom house up a found of ony strange peleantly prain. we have been many white made through it begin immece out here as they looked and pointiot-would unprebal graved in climbs is a silont bothers. but we guent bitters of a tung up fall gandalf. frodo were but of the mind points the land as thought basin's hobbits. yet, .
------ temperature:1.2
 the mind points the land as thought basin's hobbits. yet, . 'a thick folk omiding like things his stablen't,' a'sked dayy.u'
     'yes,' ask said the liateded lover. 'i bouner leapt agord which name foulk, follome.
     clear. i have wide nothobled and lodded inwittly in will a first tom grass and infford of the rouns, yourself, turning forward. i purt with him, and is passeding before brought a pool, to passing that they is moctly, and coulted.'
     'we
