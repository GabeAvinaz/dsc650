--- Generating with seed: "hasms in the walls and floor, and every now and then a crack"
------ temperature:0.2
hasms in the walls and floor, and every now and then a crack and the ring and the shadow of the ring of the mouth and the ring that was a boat was strongers and the wind the water of the shadow of the water. the stream sat sam sat for the shadows of the shadows of the shadows of the shadows of the water of the shadows of the water of the water of the shire and the low fell of the water of the shire in the shire the dark low the mountains of the shadows of 
------ temperature:0.5
e in the shire the dark low the mountains of the shadows of the enemy.
     'you may say the elves need for a great stream, and in the three seemed to the east since he had been gondor. frodo and all have come the old to a mention of the bower like a passed of the fire and the ring of the mountains was the boats and had been been dream. the through fell at the ring that he was a low flowed from the master of the shire and passed out of the shadows of the r
------ temperature:1.0
e master of the shire and passed out of the shadows of the ride butterbur were gathered by, and he was a looked, they attrouced a gently sale of mree of which thick. sam was only is name.
     the smoke down rivender or word, and i still set leaving the shadow that gave forth riskinging; 
     ahiap very very lait him! but that verase to all the feet gifor. along the aretor, at guessed air, as he were new broad there are,' said alareed, eacher and here up 
------ temperature:1.2
were new broad there are,' said alareed, eacher and here up pissiousy dragged,
           you'll ule ear,' said at leasn and unseas feelfara, onethofe-troll,' said gamded, in through. at maybe. though dleet tildly at last secreted you. aragorn looking that leivencorald me all name,' said stanils. the youe, tom arged twiri thic lhavinies.
     ut in their weaks the leaves i haping peliy, and of toporlw a rest by night to pill shellin,
            nevering e
