--- Generating with seed: "ntful years. most of the inhabitants of bree and staddle, an"
------ temperature:0.2
ntful years. most of the inhabitants of bree and staddle, and the country of the watch and startly of the stars of the shire they saw that we cannot see the water of the shire. the seas of the shire of the shire of the shire the broor of the riders. the story of the shire, and the strangers was still to the stream and the stars of the shire of the shire. it was a shadow of the shire, and the trees of the riders and the strange strangers and the stars of th
------ temperature:0.5
 of the riders and the strange strangers and the stars of the three of the sun was long to his bal laughed and the others of place fell. there are even the hobbits of the shire of the wismant. i cannot made a lad a west, and they were seen the elves of the mountains, and some round to the stars. they were seemed to be let the power of the riders. the trees is all that one of the shire, and it has get at sat for the great broad as you may have to see with a
------ temperature:1.0
get at sat for the great broad as you may have to see with a while. at let the riders. on a ppinside to go still the hole,' said frodo. `even these twicionss, where poorenty, and they said.
     `i don't mugmen't lioping frodo, faint towards his own a handing remarrabled a noise under the blead beyond askind into dark track stone.
     'half to do the elvish.
     'fell more then,' arswef ended the lowen back. though the west was a counsel rode very cut to
------ temperature:1.2
e lowen back. though the west was a counsel rode very cut to take,' gandalf later the comp and dead!
      reasy gelding cloud of bldell, and did not be waited un aharnty packs, midrily,' he came. eyonged sam left one lightered. clilf do you went up on out: itui's clear as he did you failly,' entoomed, and put the company, let a pidgy rong windos hilds
           cresply highlioping bethrol. as then gandalf was out armlsen's faged or green. as i elve, sudd
