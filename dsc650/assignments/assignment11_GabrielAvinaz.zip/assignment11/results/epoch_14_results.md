--- Generating with seed: "; and aragorn the traveller.'
     `and one hobbit! ' cried "
------ temperature:0.2
; and aragorn the traveller.'
     `and one hobbit! ' cried a shadow that they said, and the shadow still startly they saw that he had been the stream and the shadow of the shadow of the silence of the shadow and the stream of the stream and the shadow of the stream that they had not a strange stars of the shadow and the stream streamed of the stream that they had been and strange strange strange stream of the stream and the course of the stream was they h
------ temperature:0.5
stream of the stream and the course of the stream was they had not there and his hear that i am they forgiltered and could found his eyes, if they had not looked out of the country. i have not suddenly that stood out of the mirror of the new silently. they were driven on the great ancient side of the shadow and sauron was stood that they was a still did not know the shadow of the pony, and he was the stars, and let us and seen the flat to a spath, and now 
------ temperature:1.0
the stars, and let us and seen the flat to a spath, and now i feared, but made story.'
     'you came hard better streamed tall, endors possessign as if never weat. am liess, and they attried: i saw cold, if i ask exiler?' asked the shit north. not for the father-hair worederly leading. they shone do before it is. but he could not gose!' and that may talk how to also sing to the endorbge, yared acon the higher did begin a great plathing fings here'as farm 
------ temperature:1.2
on the higher did begin a great plathing fings here'as farm the which upon almost out, and sout! frouchie must took go with worst unlaitains. nobit of forceidec, from her paces. it were taling lot of trees to be seen-_coming out of the waters and airs.
     'there were to say.'
     my flight could perile wear in allasted, come to himself for all fiddriofs could!' the suddenly sittingledge!' the westhed. that sat chambs in hisher better that guarded disjut
