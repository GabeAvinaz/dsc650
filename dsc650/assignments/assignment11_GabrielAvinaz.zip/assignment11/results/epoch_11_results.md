--- Generating with seed: ". they started, and sam drew his sword and stood over frodo;"
------ temperature:0.2
. they started, and sam drew his sword and stood over frodo; but i have been make the sun his borders of the ring and the stars. the sun the trees of the stream and the marshers of the sun hill the land of the sun the hill and the pale of the water was a strange watch the stream with a stream and stars of the elves and the black windows of the morning of the shire with the mirst of the end of the elven-master of the windows and the stars. i have said the s
------ temperature:0.5
elven-master of the windows and the stars. i have said the sun is a sound and the marshers of the night. the wind growing the mountains of the water long only at him on the last or in the rings of the middle-falling to the sun with the wiseve and the morning of the world and followed and agarn them was better was still the morning of the land of the land the rings when the brandy here at last the wild was gone by the party to some set the ring north of the
------ temperature:1.0
wild was gone by the party to some set the ring north of the trees time in the horse; and i shuck, i could long to trust came them up or there. the coriing nimbat, or these oning night dark. they will be bomtunt heard proved darkers of you, but there is it make a wide togethers of fine. there may feel an anpled hip me from it was westy had heard even moria! ' said gimli. 'i have round for him, but either the marbhe towared . the remorder that went seeds ki
------ temperature:1.2
 either the marbhe towared . the remorder that went seeds kitched else more coltory opered caraidy!' ' a
 gandon,' he cried: the roof and gandard! fol. the paath flie of them founds half-fort oeman heart to voice revarry, and youpplen an olt irve bath, as ill,' he said. 'now, to behover to grals's with, even the deally fleped the ring a stiff. a dark byly saps, in weokecing upon it.
     'i canthing him. and you glacked botters that the hundrein that alc-f
