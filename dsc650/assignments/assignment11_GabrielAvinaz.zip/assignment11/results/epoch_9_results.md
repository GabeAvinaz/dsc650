--- Generating with seed: "re wargs and werewolves; and there have been and still are m"
------ temperature:0.2
re wargs and werewolves; and there have been and still are more and the water of the strength, and the world was strider seemed to the shire, and the river that he was a start of the stream that the ring was starts and the shadow of the south of the shire and the world in the shire that he stared and still and starts of the stream that is the strength were to the shire. the shadow of the three was strider start. there was a shall seemed to the shire that w
------ temperature:0.5
 strider start. there was a shall seemed to the shire that were sat in the grey of the company they sent that he could be desire as he was still that the sun still things the led the rings of the matter of the counsen and start of the stream with the lands the swords and spoke, and the heavy still and better was presently to the doors were long and sure and his in frodo, and with a see that would see the hobbits, and we have sleeped to the strength. the ot
------ temperature:1.0
see the hobbits, and we have sleeped to the strength. the others that seemed to ried,' he said. 'that my blodom. it dared the gras bo wes, and going to me in came into the winds and the dirlitrest. as this, little inpoortesty we creating on, then _tuin frodo, i can think, as he forty bookonion is it, antofl gandalf guessed, and his me, in all the top !not op. the dwarves valbe: quick looped. but in the virious knew acaman and lay for the fire there frodo. 
------ temperature:1.2
n the virious knew acaman and lay for the fire there frodo. there, for sam never- further ip aragorn,
           or spag, sunli'lgs.'
     'he had to your end shall rings sind ago,' said stairier. 'spring and forgot that shiny compone.'
     'but there even and a large was little grime,' said gimli. 'but now be blowd. the deep and food spoke gleaming, a canhoge!'
     'you'll be inside. we cangoldred. indeed, agot, frodo caught food the boots and pale two 
